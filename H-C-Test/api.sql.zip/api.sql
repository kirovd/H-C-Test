-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 29, 2021 at 05:31 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET FOREIGN_KEY_CHECKS=0;
SET AUTOCOMMIT = 0;
START TRANSACTION;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `api`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--
-- Creation: Jul 26, 2021 at 11:53 PM
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `admins`:
--

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin'),
(2, 'admin', 'admin123'),
(3, 'admin', 'admin1234');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--
-- Creation: Jul 29, 2021 at 03:48 AM
-- Last update: Jul 29, 2021 at 03:48 AM
--

CREATE TABLE `packages` (
  `id` int(11) NOT NULL,
  `name` varchar(180) NOT NULL DEFAULT '',
  `description` varchar(220) NOT NULL DEFAULT '',
  `commitment_period` int(2) UNSIGNED NOT NULL DEFAULT 0,
  `credits` int(9) UNSIGNED NOT NULL DEFAULT 0,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `sell_limit` int(4) UNSIGNED DEFAULT NULL,
  `remarks` varchar(180) NOT NULL,
  `package_id` int(11) NOT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `packages`:
--

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `name`, `description`, `commitment_period`, `credits`, `enabled`, `sell_limit`, `remarks`, `package_id`) VALUES
(1, 'harley', 'The packages purchased by harley are still being considered.', 0, 0, 1, 2, '', 1),
(2, 'joker', 'joker bought few of the packages', 0, 0, 1, 3, '', 2),
(3, 'morgana', 'She has bought one of the packages', 2, 5, 1, 2, '', 3),
(23, 'kylee', 'Package is bought for the first time', 2, 5, 1, 2, '', 0),
(28, 'jamie', 'Bought a package', 2, 5, 1, 1, '', 0),
(29, 'kylee', '', 0, 0, 1, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--
-- Creation: Jul 29, 2021 at 03:19 AM
-- Last update: Jul 29, 2021 at 03:49 AM
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `register`:
--

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `username`, `password`, `user_id`) VALUES
(14, 'user', '123', 1),
(15, 'user', 'joker', 2),
(16, 'user', 'jks', 3),
(17, 'user', 'joker', 4),
(18, 'user', 'joker', 5),
(19, 'joker', 'jj', 6),
(20, 'user', 'jjj', 7),
(21, 'wkks', 'jjjj', 8),
(22, 'wkks', 'jjjj', 9),
(23, 'wkks', 'jjjj', 10),
(24, 'wkks', 'jjjj', 11),
(25, 'user', '', 0),
(26, 'kylee', 'ky;ee123', 0),
(28, 'kyle', 'ky;ee123', 0),
(30, 'john', 'ky;ee123', 0),
(32, 'john', 'john123', 0),
(33, 'danny', 'danny', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Creation: Jul 29, 2021 at 03:44 AM
-- Last update: Jul 29, 2021 at 03:46 AM
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(180) NOT NULL DEFAULT '',
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `remarks` varchar(180) NOT NULL,
  `user_id` int(11) NOT NULL,
  `purchased_credits` int(9) NOT NULL DEFAULT 1
) ;

--
-- RELATIONSHIPS FOR TABLE `users`:
--

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `enabled`, `remarks`, `user_id`, `purchased_credits`) VALUES
(1, 'harley', 1, 'remarks', 1, 0),
(2, 'joker', 1, 'remarks', 2, 0),
(3, 'morgana', 1, 'remarks', 3, 0),
(7, 'kylee', 1, '', 7, 0),
(13, 'josh', 1, '', 0, 3),
(15, 'jamie', 1, '', 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `user_packages`
--
-- Creation: Jul 29, 2021 at 03:45 AM
-- Last update: Jul 29, 2021 at 01:04 AM
--

CREATE TABLE `user_packages` (
  `id` int(11) NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `package_id` int(11) UNSIGNED NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL
) ;

--
-- RELATIONSHIPS FOR TABLE `user_packages`:
--

--
-- Dumping data for table `user_packages`
--

INSERT INTO `user_packages` (`id`, `user_id`, `package_id`, `start_date`, `end_date`) VALUES
(1, 1, 1, '2021-07-28', NULL),
(2, 2, 2, '2021-07-29', NULL),
(3, 3, 3, '2021-07-29', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_packages`
--
ALTER TABLE `user_packages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `FOREIGN` (`user_id`,`package_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_packages`
--
ALTER TABLE `user_packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;


--
-- Metadata
--
USE phpmyadmin;

--
-- Metadata for table admins
--

--
-- Metadata for table packages
--

--
-- Metadata for table register
--

--
-- Dumping data for table `pma__table_uiprefs`
--

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'api', 'register', '{\"sorted_col\":\"`register`.`user_id`  DESC\"}', '2021-07-29 03:13:56');

--
-- Metadata for table users
--

--
-- Dumping data for table `pma__table_uiprefs`
--

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'api', 'users', '{\"CREATE_TIME\":\"2021-07-29 03:44:54\",\"sorted_col\":\"`users`.`purchased_credits`  ASC\",\"col_order\":[0,1,5,2,3,4],\"col_visib\":[1,1,1,1,1,1]}', '2021-07-29 03:46:09');

--
-- Metadata for table user_packages
--

--
-- Dumping data for table `pma__table_uiprefs`
--

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'api', 'user_packages', '{\"CREATE_TIME\":\"2021-07-29 00:23:26\"}', '2021-07-29 01:00:53');

--
-- Metadata for database api
--
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
